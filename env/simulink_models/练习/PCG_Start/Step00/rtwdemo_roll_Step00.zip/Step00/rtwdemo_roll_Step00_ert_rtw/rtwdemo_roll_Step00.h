/*
 * File: rtwdemo_roll_Step00.h
 *
 * Code generated for Simulink model 'rtwdemo_roll_Step00'.
 *
 * Model version                  : 6.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sun Jan 15 14:47:32 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rtwdemo_roll_Step00_h_
#define RTW_HEADER_rtwdemo_roll_Step00_h_
#ifndef rtwdemo_roll_Step00_COMMON_INCLUDES_
#define rtwdemo_roll_Step00_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                /* rtwdemo_roll_Step00_COMMON_INCLUDES_ */

#include "rtwdemo_roll_Step00_types.h"
#include <stddef.h>
#include <string.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real32_T phiCmd;                     /* '<Root>/ModeSwitch' */
  real32_T hdgError;                   /* '<S2>/Sum' */
  real32_T DispGain;                   /* '<S2>/DispGain' */
  real32_T Product;                    /* '<S2>/Product' */
  real32_T Abs;                        /* '<S3>/Abs' */
  real32_T FixPtUnitDelay1;            /* '<S4>/FixPt Unit Delay1' */
  real32_T TKSwitch;                   /* '<S3>/TKSwitch' */
  real32_T Xnew;                       /* '<S4>/Enable' */
  real32_T RefSwitch;                  /* '<S3>/RefSwitch' */
  real32_T Integrator;                 /* '<S1>/Integrator' */
  real32_T DispLimit;                  /* '<S1>/DispLimit' */
  real32_T Sum;                        /* '<S1>/Sum' */
  real32_T DispGain_f;                 /* '<S1>/DispGain' */
  real32_T RateLimit;                  /* '<S1>/RateLimit' */
  real32_T Sum1;                       /* '<S1>/Sum1' */
  real32_T RateGain;                   /* '<S1>/RateGain' */
  real32_T Sum2;                       /* '<S1>/Sum2' */
  real32_T CmdLimit;                   /* '<S1>/CmdLimit' */
  real32_T IntGain;                    /* '<S1>/IntGain' */
  struct {
    uint_T TKThreshold:1;              /* '<S3>/TKThreshold' */
    uint_T NotEngaged:1;               /* '<S3>/NotEngaged' */
    uint_T RefThreshold2:1;            /* '<S3>/RefThreshold2' */
    uint_T RefThreshold1:1;            /* '<S3>/RefThreshold1' */
    uint_T Or:1;                       /* '<S3>/Or' */
    uint_T NotEngaged_e:1;             /* '<S1>/NotEngaged' */
  } bitsForTID0;
} B;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real32_T FixPtUnitDelay1_DSTATE;     /* '<S4>/FixPt Unit Delay1' */
  real32_T Integrator_DSTATE;          /* '<S1>/Integrator' */
  int8_T Integrator_PrevResetState;    /* '<S1>/Integrator' */
} DW;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real32_T Phi;                        /* '<Root>/Phi' */
  real32_T Psi;                        /* '<Root>/Psi' */
  real32_T Rate_FB;                    /* '<Root>/Rate_FB' */
  real32_T TAS;                        /* '<Root>/TAS' */
  boolean_T AP_Eng;                    /* '<Root>/AP_Eng' */
  boolean_T HDG_Mode;                  /* '<Root>/HDG_Mode' */
  real32_T HDG_Ref;                    /* '<Root>/HDG_Ref' */
  real32_T Turn_Knob;                  /* '<Root>/Turn_Knob' */
} ExtU;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real32_T Ail_Cmd;                    /* '<Root>/Ail_Cmd' */
} ExtY;

/* Parameters (default storage) */
struct P_ {
  real32_T cmdLim;                     /* Variable: cmdLim
                                        * Referenced by: '<S1>/CmdLimit'
                                        */
  real32_T dispGain;                   /* Variable: dispGain
                                        * Referenced by: '<S1>/DispGain'
                                        */
  real32_T dispLim;                    /* Variable: dispLim
                                        * Referenced by: '<S1>/DispLimit'
                                        */
  real32_T hdgGain;                    /* Variable: hdgGain
                                        * Referenced by: '<S2>/DispGain'
                                        */
  real32_T intGain;                    /* Variable: intGain
                                        * Referenced by: '<S1>/IntGain'
                                        */
  real32_T intLim;                     /* Variable: intLim
                                        * Referenced by: '<S1>/Integrator'
                                        */
  real32_T rateGain;                   /* Variable: rateGain
                                        * Referenced by: '<S1>/RateGain'
                                        */
  real32_T rateLim;                    /* Variable: rateLim
                                        * Referenced by: '<S1>/RateLimit'
                                        */
  real32_T LatchPhi_vinit;             /* Mask Parameter: LatchPhi_vinit
                                        * Referenced by: '<S4>/FixPt Unit Delay1'
                                        */
  real32_T Integrator_gainval;         /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S1>/Integrator'
                                        */
  real32_T Integrator_IC;              /* Computed Parameter: Integrator_IC
                                        * Referenced by: '<S1>/Integrator'
                                        */
  real32_T Integrator_LowerSat;       /* Computed Parameter: Integrator_LowerSat
                                       * Referenced by: '<S1>/Integrator'
                                       */
  real32_T DispLimit_LowerSat;         /* Computed Parameter: DispLimit_LowerSat
                                        * Referenced by: '<S1>/DispLimit'
                                        */
  real32_T RateLimit_LowerSat;         /* Computed Parameter: RateLimit_LowerSat
                                        * Referenced by: '<S1>/RateLimit'
                                        */
  real32_T CmdLimit_LowerSat;          /* Computed Parameter: CmdLimit_LowerSat
                                        * Referenced by: '<S1>/CmdLimit'
                                        */
  real32_T Zero_Value;                 /* Computed Parameter: Zero_Value
                                        * Referenced by: '<S3>/Zero'
                                        */
  real32_T LoThr_Value;                /* Computed Parameter: LoThr_Value
                                        * Referenced by: '<S3>/LoThr'
                                        */
  real32_T UpThr_Value;                /* Computed Parameter: UpThr_Value
                                        * Referenced by: '<S3>/UpThr'
                                        */
  real32_T Three_Value;                /* Computed Parameter: Three_Value
                                        * Referenced by: '<S3>/Three'
                                        */
  real32_T Zero_Value_c;               /* Computed Parameter: Zero_Value_c
                                        * Referenced by: '<Root>/Zero'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T * volatile errorStatus;
};

/* Block parameters (default storage) */
extern P rtP;

/* Block signals (default storage) */
extern B rtB;

/* Block states (default storage) */
extern DW rtDW;

/* External inputs (root inport signals with default storage) */
extern ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY rtY;

/* Model entry point functions */
extern void rtwdemo_roll_Step00_initialize(void);
extern void rtwdemo_roll_Step00_step(void);
extern void rtwdemo_roll_Step00_terminate(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S4>/FixPt Data Type Duplicate1' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'rtwdemo_roll_Step00'
 * '<S1>'   : 'rtwdemo_roll_Step00/BasicRollMode'
 * '<S2>'   : 'rtwdemo_roll_Step00/HeadingMode'
 * '<S3>'   : 'rtwdemo_roll_Step00/RollAngleReference'
 * '<S4>'   : 'rtwdemo_roll_Step00/RollAngleReference/LatchPhi'
 */

/*-
 * Requirements for '<Root>': rtwdemo_roll_Step00

 */
#endif                                 /* RTW_HEADER_rtwdemo_roll_Step00_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
