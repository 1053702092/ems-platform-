/*
 * File: rtwdemo_roll_Step00_data.c
 *
 * Code generated for Simulink model 'rtwdemo_roll_Step00'.
 *
 * Model version                  : 6.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sun Jan 15 14:47:32 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtwdemo_roll_Step00.h"

/* Block parameters (default storage) */
P rtP = {
  /* Variable: cmdLim
   * Referenced by: '<S1>/CmdLimit'
   */
  15.0F,

  /* Variable: dispGain
   * Referenced by: '<S1>/DispGain'
   */
  0.75F,

  /* Variable: dispLim
   * Referenced by: '<S1>/DispLimit'
   */
  30.0F,

  /* Variable: hdgGain
   * Referenced by: '<S2>/DispGain'
   */
  0.015F,

  /* Variable: intGain
   * Referenced by: '<S1>/IntGain'
   */
  0.5F,

  /* Variable: intLim
   * Referenced by: '<S1>/Integrator'
   */
  5.0F,

  /* Variable: rateGain
   * Referenced by: '<S1>/RateGain'
   */
  2.0F,

  /* Variable: rateLim
   * Referenced by: '<S1>/RateLimit'
   */
  6.0F,

  /* Mask Parameter: LatchPhi_vinit
   * Referenced by: '<S4>/FixPt Unit Delay1'
   */
  0.0F,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S1>/Integrator'
   */
  0.025F,

  /* Computed Parameter: Integrator_IC
   * Referenced by: '<S1>/Integrator'
   */
  0.0F,

  /* Computed Parameter: Integrator_LowerSat
   * Referenced by: '<S1>/Integrator'
   */
  -5.0F,

  /* Computed Parameter: DispLimit_LowerSat
   * Referenced by: '<S1>/DispLimit'
   */
  -30.0F,

  /* Computed Parameter: RateLimit_LowerSat
   * Referenced by: '<S1>/RateLimit'
   */
  -6.0F,

  /* Computed Parameter: CmdLimit_LowerSat
   * Referenced by: '<S1>/CmdLimit'
   */
  -15.0F,

  /* Computed Parameter: Zero_Value
   * Referenced by: '<S3>/Zero'
   */
  0.0F,

  /* Computed Parameter: LoThr_Value
   * Referenced by: '<S3>/LoThr'
   */
  -6.0F,

  /* Computed Parameter: UpThr_Value
   * Referenced by: '<S3>/UpThr'
   */
  6.0F,

  /* Computed Parameter: Three_Value
   * Referenced by: '<S3>/Three'
   */
  3.0F,

  /* Computed Parameter: Zero_Value_c
   * Referenced by: '<Root>/Zero'
   */
  0.0F
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
