/*
 * File: rtwdemo_roll_Step00_types.h
 *
 * Code generated for Simulink model 'rtwdemo_roll_Step00'.
 *
 * Model version                  : 6.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sun Jan 15 14:47:32 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rtwdemo_roll_Step00_types_h_
#define RTW_HEADER_rtwdemo_roll_Step00_types_h_

/* Parameters (default storage) */
typedef struct P_ P;

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

#endif                             /* RTW_HEADER_rtwdemo_roll_Step00_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
