function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtB"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	size: 80};
	 this.metricsArray.var["rtDW"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	size: 12};
	 this.metricsArray.var["rtP"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00_data.c",
	size: 80};
	 this.metricsArray.var["rtU"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	size: 28};
	 this.metricsArray.var["rtY"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	size: 4};
	 this.metricsArray.var["rtwdemo_roll_Step00.c:rtM_"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	size: 8};
	 this.metricsArray.fcn["fabs"] = {file: "C:\\Matlab\\R2022b\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memset"] = {file: "C:\\Matlab\\R2022b\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtwdemo_roll_Step00_initialize"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtwdemo_roll_Step00_step"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	stack: 12,
	stackTotal: 12};
	 this.metricsArray.fcn["rtwdemo_roll_Step00_terminate"] = {file: "C:\\Demo\\Code_PCG\\GS22b\\Step00\\rtwdemo_roll_Step00_ert_rtw\\rtwdemo_roll_Step00.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'rtwdemo_roll_Step00_metrics\'});">Global Memory: 212(bytes) Maximum Stack: 12(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
