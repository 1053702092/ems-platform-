/*
 * File: rtwdemo_roll_Step00.c
 *
 * Code generated for Simulink model 'rtwdemo_roll_Step00'.
 *
 * Model version                  : 6.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sun Jan 15 14:47:32 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtwdemo_roll_Step00.h"
#include <math.h>
#include "rtwtypes.h"
#include <string.h>

/* Block signals (default storage) */
B rtB;

/* Block states (default storage) */
DW rtDW;

/* External inputs (root inport signals with default storage) */
ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
ExtY rtY;

/* Real-time model */
static RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;

/* Model step function */
void rtwdemo_roll_Step00_step(void)
{
  real32_T u0;
  real32_T u1;
  real32_T u2;

  /* Outputs for Atomic SubSystem: '<Root>/RollAngleReference' */
  /* Abs: '<S3>/Abs' incorporates:
   *  Inport: '<Root>/Turn_Knob'
   */
  rtB.Abs = (real32_T)fabs(rtU.Turn_Knob);

  /* RelationalOperator: '<S3>/TKThreshold' incorporates:
   *  Constant: '<S3>/Three'
   */
  rtB.bitsForTID0.TKThreshold = (rtB.Abs < rtP.Three_Value);

  /* UnitDelay: '<S4>/FixPt Unit Delay1' */
  rtB.FixPtUnitDelay1 = rtDW.FixPtUnitDelay1_DSTATE;

  /* Switch: '<S3>/TKSwitch' */
  if (rtB.bitsForTID0.TKThreshold) {
    /* Switch: '<S3>/TKSwitch' */
    rtB.TKSwitch = rtB.FixPtUnitDelay1;
  } else {
    /* Switch: '<S3>/TKSwitch' incorporates:
     *  Inport: '<Root>/Turn_Knob'
     */
    rtB.TKSwitch = rtU.Turn_Knob;
  }

  /* End of Switch: '<S3>/TKSwitch' */

  /* Logic: '<S3>/NotEngaged' incorporates:
   *  Inport: '<Root>/AP_Eng'
   */
  rtB.bitsForTID0.NotEngaged = !rtU.AP_Eng;

  /* Switch: '<S4>/Enable' */
  if (rtB.bitsForTID0.NotEngaged) {
    /* RelationalOperator: '<S3>/RefThreshold2' incorporates:
     *  Constant: '<S3>/LoThr'
     *  Inport: '<Root>/Phi'
     */
    rtB.bitsForTID0.RefThreshold2 = (rtU.Phi <= rtP.LoThr_Value);

    /* RelationalOperator: '<S3>/RefThreshold1' incorporates:
     *  Constant: '<S3>/UpThr'
     *  Inport: '<Root>/Phi'
     */
    rtB.bitsForTID0.RefThreshold1 = (rtU.Phi >= rtP.UpThr_Value);

    /* Logic: '<S3>/Or' */
    rtB.bitsForTID0.Or = (rtB.bitsForTID0.RefThreshold1 ||
                          rtB.bitsForTID0.RefThreshold2);

    /* Switch: '<S3>/RefSwitch' */
    if (rtB.bitsForTID0.Or) {
      /* Switch: '<S3>/RefSwitch' incorporates:
       *  Inport: '<Root>/Phi'
       */
      rtB.RefSwitch = rtU.Phi;
    } else {
      /* Switch: '<S3>/RefSwitch' incorporates:
       *  Constant: '<S3>/Zero'
       */
      rtB.RefSwitch = rtP.Zero_Value;
    }

    /* End of Switch: '<S3>/RefSwitch' */

    /* Switch: '<S4>/Enable' */
    rtB.Xnew = rtB.RefSwitch;
  } else {
    /* Switch: '<S4>/Enable' */
    rtB.Xnew = rtB.FixPtUnitDelay1;
  }

  /* End of Switch: '<S4>/Enable' */

  /* Update for UnitDelay: '<S4>/FixPt Unit Delay1' */
  rtDW.FixPtUnitDelay1_DSTATE = rtB.Xnew;

  /* End of Outputs for SubSystem: '<Root>/RollAngleReference' */

  /* Switch: '<Root>/ModeSwitch' incorporates:
   *  Inport: '<Root>/HDG_Mode'
   */
  if (rtU.HDG_Mode) {
    /* Outputs for Atomic SubSystem: '<Root>/HeadingMode' */
    /* Sum: '<S2>/Sum' incorporates:
     *  Inport: '<Root>/HDG_Ref'
     *  Inport: '<Root>/Psi'
     */
    rtB.hdgError = rtU.HDG_Ref - rtU.Psi;

    /* Gain: '<S2>/DispGain' */
    rtB.DispGain = rtP.hdgGain * rtB.hdgError;

    /* Product: '<S2>/Product' incorporates:
     *  Inport: '<Root>/TAS'
     */
    rtB.Product = rtB.DispGain * rtU.TAS;

    /* End of Outputs for SubSystem: '<Root>/HeadingMode' */

    /* Switch: '<Root>/ModeSwitch' */
    rtB.phiCmd = rtB.Product;
  } else {
    /* Switch: '<Root>/ModeSwitch' */
    rtB.phiCmd = rtB.TKSwitch;
  }

  /* End of Switch: '<Root>/ModeSwitch' */

  /* Outputs for Atomic SubSystem: '<Root>/BasicRollMode' */
  /* Logic: '<S1>/NotEngaged' incorporates:
   *  Inport: '<Root>/AP_Eng'
   */
  rtB.bitsForTID0.NotEngaged_e = !rtU.AP_Eng;

  /* DiscreteIntegrator: '<S1>/Integrator' */
  if (rtB.bitsForTID0.NotEngaged_e || (rtDW.Integrator_PrevResetState != 0)) {
    rtDW.Integrator_DSTATE = rtP.Integrator_IC;
  }

  if (rtDW.Integrator_DSTATE >= rtP.intLim) {
    rtDW.Integrator_DSTATE = rtP.intLim;
  } else if (rtDW.Integrator_DSTATE <= rtP.Integrator_LowerSat) {
    rtDW.Integrator_DSTATE = rtP.Integrator_LowerSat;
  }

  /* DiscreteIntegrator: '<S1>/Integrator' */
  rtB.Integrator = rtDW.Integrator_DSTATE;

  /* Saturate: '<S1>/DispLimit' */
  u0 = rtB.phiCmd;
  u1 = rtP.DispLimit_LowerSat;
  u2 = rtP.dispLim;
  if (u0 > u2) {
    /* Saturate: '<S1>/DispLimit' */
    rtB.DispLimit = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S1>/DispLimit' */
    rtB.DispLimit = u1;
  } else {
    /* Saturate: '<S1>/DispLimit' */
    rtB.DispLimit = u0;
  }

  /* End of Saturate: '<S1>/DispLimit' */

  /* Sum: '<S1>/Sum' incorporates:
   *  Inport: '<Root>/Phi'
   */
  rtB.Sum = rtB.DispLimit - rtU.Phi;

  /* Gain: '<S1>/DispGain' */
  rtB.DispGain_f = rtP.dispGain * rtB.Sum;

  /* Saturate: '<S1>/RateLimit' */
  u0 = rtB.DispGain_f;
  u1 = rtP.RateLimit_LowerSat;
  u2 = rtP.rateLim;
  if (u0 > u2) {
    /* Saturate: '<S1>/RateLimit' */
    rtB.RateLimit = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S1>/RateLimit' */
    rtB.RateLimit = u1;
  } else {
    /* Saturate: '<S1>/RateLimit' */
    rtB.RateLimit = u0;
  }

  /* End of Saturate: '<S1>/RateLimit' */

  /* Sum: '<S1>/Sum1' incorporates:
   *  Inport: '<Root>/Rate_FB'
   */
  rtB.Sum1 = rtB.RateLimit - rtU.Rate_FB;

  /* Gain: '<S1>/RateGain' */
  rtB.RateGain = rtP.rateGain * rtB.Sum1;

  /* Sum: '<S1>/Sum2' */
  rtB.Sum2 = rtB.Integrator + rtB.RateGain;

  /* Saturate: '<S1>/CmdLimit' */
  u0 = rtB.Sum2;
  u1 = rtP.CmdLimit_LowerSat;
  u2 = rtP.cmdLim;
  if (u0 > u2) {
    /* Saturate: '<S1>/CmdLimit' */
    rtB.CmdLimit = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S1>/CmdLimit' */
    rtB.CmdLimit = u1;
  } else {
    /* Saturate: '<S1>/CmdLimit' */
    rtB.CmdLimit = u0;
  }

  /* End of Saturate: '<S1>/CmdLimit' */

  /* Gain: '<S1>/IntGain' */
  rtB.IntGain = rtP.intGain * rtB.Sum1;

  /* Update for DiscreteIntegrator: '<S1>/Integrator' */
  rtDW.Integrator_DSTATE += rtP.Integrator_gainval * rtB.IntGain;
  if (rtDW.Integrator_DSTATE >= rtP.intLim) {
    rtDW.Integrator_DSTATE = rtP.intLim;
  } else if (rtDW.Integrator_DSTATE <= rtP.Integrator_LowerSat) {
    rtDW.Integrator_DSTATE = rtP.Integrator_LowerSat;
  }

  rtDW.Integrator_PrevResetState = (int8_T)rtB.bitsForTID0.NotEngaged_e;

  /* End of Update for DiscreteIntegrator: '<S1>/Integrator' */
  /* End of Outputs for SubSystem: '<Root>/BasicRollMode' */

  /* Switch: '<Root>/EngSwitch' incorporates:
   *  Inport: '<Root>/AP_Eng'
   */
  if (rtU.AP_Eng) {
    /* Outport: '<Root>/Ail_Cmd' */
    rtY.Ail_Cmd = rtB.CmdLimit;
  } else {
    /* Outport: '<Root>/Ail_Cmd' incorporates:
     *  Constant: '<Root>/Zero'
     */
    rtY.Ail_Cmd = rtP.Zero_Value_c;
  }

  /* End of Switch: '<Root>/EngSwitch' */
}

/* Model initialize function */
void rtwdemo_roll_Step00_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(rtM, (NULL));

  /* block I/O */
  (void) memset(((void *) &rtB), 0,
                sizeof(B));

  /* states (dwork) */
  (void) memset((void *)&rtDW, 0,
                sizeof(DW));

  /* external inputs */
  (void)memset(&rtU, 0, sizeof(ExtU));

  /* external outputs */
  rtY.Ail_Cmd = 0.0F;

  /* SystemInitialize for Atomic SubSystem: '<Root>/RollAngleReference' */
  /* InitializeConditions for UnitDelay: '<S4>/FixPt Unit Delay1' */
  rtDW.FixPtUnitDelay1_DSTATE = rtP.LatchPhi_vinit;

  /* End of SystemInitialize for SubSystem: '<Root>/RollAngleReference' */

  /* SystemInitialize for Atomic SubSystem: '<Root>/BasicRollMode' */
  /* InitializeConditions for DiscreteIntegrator: '<S1>/Integrator' */
  rtDW.Integrator_DSTATE = rtP.Integrator_IC;
  rtDW.Integrator_PrevResetState = 0;

  /* End of SystemInitialize for SubSystem: '<Root>/BasicRollMode' */
}

/* Model terminate function */
void rtwdemo_roll_Step00_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
