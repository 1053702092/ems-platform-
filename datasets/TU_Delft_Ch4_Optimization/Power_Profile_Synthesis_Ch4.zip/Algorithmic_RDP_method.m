%% Test Douglas�Peucker algorithm 
% The Ramer�Douglas�Peucker algorithm (RDP) is an algorithm for reducing 
% the number of points in a curve that is approximated by a series of 
% points. The initial form of the algorithm was independently suggested 
% in 1972 by Urs Ramer and 1973 by David Douglas and Thomas Peucker and 
% several others in the following decade. This algorithm is also known 
% under the names Douglas�Peucker algorithm, iterative end-point fit 
% algorithm and split-and-merge algorithm. [Source Wikipedia]
%
%
% -------------------------------------------------------
% Code: Reza Ahmadzadeh (2017) 
% -------------------------------------------------------

clc,clear,close all



profile_data = xlsread('NoZerosFullProfile.xlsx');
time = profile_data(:,1)/1440; % days
demand = profile_data(:,2); % power kW


Points = [time';
    demand'];

figure;
ii = 1;
subplot(2,3,ii);hold on
plot(Points(1,:),Points(2,:),'-or');
title('initial points');
grid on;box on;axis([0 1.1343e3 0 1300]);

for epsilon = 0.9 % for 300 data
    res = DouglasPeucker(Points,epsilon);
    ii = ii + 1;
    subplot(2,3,ii);hold on
    plot(Points(1,:),Points(2,:),'--or');
    plot(res(1,:),res(2,:),'-xb');
    title(['\epsilon = ' num2str(epsilon)]);
    grid on;box on;axis([0 1.1343e3 0 1300]);
    legend('original','approximated')
end


% Plots specifications
fs = 24;
set(0, 'defaultAxesTickLabelInterpreter', 'latex')
set(0, 'defaultTextInterpreter', 'latex')
set(0, 'defaultLegendInterpreter', 'latex')
set(0, 'defaultAxesFontSize', fs)
set(0, 'defaultTextFontSize', fs)
set(0, 'defaultLegendFontSize',fs)

%Plot Original vs reduced data
figure('position',[50,50,1000,600]), hold on, grid on, box on
plot(time',demand','-b','linewidth',2,'Displayname','Original Data');
plot(res(1,:),res(2,:),'-r','linewidth',2,'Displayname','Reduced Data');
xlabel('Time [Days]','Interpreter','latex',FontSize=fs); 
ylabel('Power [kW]','Interpreter','latex',FontSize=fs); 
legend show
name = 'RDP.png';
%xlim([0 110]);
print(sprintf('%s',name),'-dpng','-r0');

