
data = readtable('upload.xlsx');

% Extract the consecutive differences from the first column
diff_ranges_str = data{:, 1}; % These are strings like '-1000--900'
% Convert the strings to the midpoints of the ranges
%diff_ranges = str2double(regexprep(diff_ranges_str, {'--','-'}, '-'));

correct_data = xlsread('diff_ranges.xlsx');

diff_ranges = correct_data(:,3);

% Extract the probability matrix (columns represent ranges from 0-100 to 1300-1400)
prob_matrix = data{1:46,2:14};  % Adjust to capture the correct columns for value ranges

% Replace any NaN values in the probability matrix with zero (if applicable)
prob_matrix(isnan(prob_matrix)) = 0;

% Normalize the probability matrix to ensure probabilities sum to 1
total_prob = sum(prob_matrix(:));
if total_prob == 0
    error('The probability matrix is all zeros.');
end
prob_matrix = prob_matrix ./ total_prob;

% Flatten the probability matrix into a single vector for sampling
flattened_prob_matrix = prob_matrix(:);

% Define the number of points in the time series
n_points = 300;

% Initialize the time series
time_series = zeros(n_points, 1);

% Set the maximum limit for the time series values
max_value = 1300;

% Generate the time series using probability distribution
for i = 2:n_points
    % Sample from the entire flattened probability matrix
    sampled_index = randsample(length(flattened_prob_matrix), 1, true, flattened_prob_matrix);
    
    % Convert the flat index back to row and column of the probability matrix
    [diff_row, col] = ind2sub(size(prob_matrix), sampled_index);
    
    % Get the corresponding difference value from diff_ranges
    diff_value = diff_ranges(diff_row);
    
    % Update the time series by adding the difference value
    next_value = time_series(i-1) + diff_value;
    
    % Ensure the next value does not exceed the max_value (1300)
    if next_value > max_value
        time_series(i) = max_value;
    elseif next_value < 0
        time_series(i) = 0; % Prevent values from going below 0
    else
        time_series(i) = next_value;
    end
end

% last element to be zero - i migth delete this part.
%time_series(end)=0;

% Plot the generated time series
plot(time_series);
xlabel('Time');
ylabel('Value');
title('Generated Time Series (Capped at 1300)');
