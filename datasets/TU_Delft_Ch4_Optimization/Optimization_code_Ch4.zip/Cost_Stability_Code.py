# Cost-optimal retrofit with stability (variable Nfc, Nbat), placement, ballast selection

from pyscipopt import Model, quicksum
import pandas as pd
import matplotlib.pyplot as plt
import math
import numpy as np
import os


fs = 30
plt.rcParams.update({
    'text.usetex': False,
    'font.size': fs,
    'axes.titlesize': fs,
    'axes.labelsize': fs,
    'xtick.labelsize': fs,
    'ytick.labelsize': fs,
    'legend.fontsize': 22,
    'figure.figsize': (12, 6),
    'lines.linewidth': 2,
    'axes.grid': True,
    'legend.loc': 'best'
})




# Bounds for component counts
NFC_MIN, NFC_MAX = 14, 17  # fuel cells
NBAT_MIN, NBAT_MAX = 3, 6 # batteries

# Main params
Pfc_rated = 100  # kW per FC stack
Pfc_min = 0.1 * Pfc_rated
Pfc_max = Pfc_rated

Ebatt_rated = 60  # kWh per battery unit
Crate_max_disch = 1
Crate_max_charge = -1
Pbatt_max_disch = Crate_max_disch * Ebatt_rated
Pbatt_max_charge = Crate_max_charge * Ebatt_rated

Vol_spec = 0.0248   # m^3 per kg H2 (LH2 tank sizing)
Grav_spec = 8.7     # kg tank / kg hydrogen (LH2 tank)
SoCmin, SoCmax, SoCinitial = 0.2, 0.8, 0.5
Sampling_dt = 300 / 3600  # h
a_quadratic, b_quadratic, c_quadratic = 0.0066, 1.4025, 1.8306
Pramp_min, Pramp_max = -Pfc_rated, Pfc_rated
Conversion_coefficient = 0.03

Length_tank = 7.5
converter_height = 0.18

annual_trips = 200
years = 20
cost_hydrogen = 6

#cost_hydrogen = 5
#cost_hydrogen = 4
#cost_hydrogen = 3

#cost_hydrogen = 12
#cost_hydrogen = 9 




# sensitivity
#cost_hydrogen = 6*0.95
#cost_hydrogen = 6*1.05
#cost_hydrogen = 6*0.9
#cost_hydrogen = 6*1.1


interest_rate = 0.05

# CAPEX
Cost_fc = 1014          # $/kW







Cost_bat = 492          # $/kWh


Cost_LH2_tank = 233     # $/kg hydrogen

# sensitivity analysis
#Cost_LH2_tank = 233*0.9    # $/kg hydrogen
#Cost_LH2_tank = 233*0.95   # $/kg hydrogen
#Cost_LH2_tank = 233*1.05  # $/kg hydrogen
#Cost_LH2_tank = 233*1.1  # $/kg hydrogen





Cost_converters = 216   # $/kW (also used for inverter)
motor_power = 1400      # kW per motor
inverter_power = 1400   # kW per inverter 
Cost_motors = 133       # $/kW
Cost_gearbox = 72200    # $ (one gearbox)

# Replacement costs & years
Cost_fuelcell_replace = 0.5 * Cost_fc
Cost_batt_replace = 0.5 * Cost_bat
fuelcell_replacement_years = [4, 8, 12, 16]
battery_replacement_years = [7, 14]

# Maintenance ($/year)
Cfc_mainten = 0.01 * Cost_fc
Cbat_mainten = 0.5
Cconverter_mainten = 2.6
Cmotor_mainten = 1.3

# Vessel weights 
original_lightship_weight = 1172.203 * 1000  # kg
KG_original_lightship = 5.17

engine_weight = 11600
engine_height = 2.076
z_engine = 1.0

# DWT homogeneous loaded condition 
DWT_loaded_original = 3663.641 * 1000
KG_DWT_loaded_original = 4.974

# Removed fuel (diesel) case
DWT_removal_weight = 274.84 * 1000
KG_DWT_removal = 4.189

# Ballast in original (removed)
DWT_ballast_removal_homogeneous = 28.153 * 1000
KG_DWT_ballast_removal_homogeneous = 1.381
LCG_DWT_ballast_removal_homogeneous = 40.9

# Propulsion  items
w_motor, n_motor, h_motor, eff_motor = 5800, 1, 2.06, 0.95
w_inverter, n_inverter, h_inverter, eff_inverter = 63*2, 1, 0.88, 0.985
w_gearbox, n_gearbox, h_gearbox, eff_gearbox = 3800, 1, 1.3, 0.94

# tank location
Height_tank_above_keel = 8.0
# sensitivity check
#Height_tank_above_keel = 1



w_fc, fixed_h_fc, eff_fuelcell = 212, 0.674, 0.55
converter_weight, eff_converter = 38, 0.985
GM_min = 0.3
#H_max_fuel_cells = 5*fixed_h_fc - fixed_h_fc + 1  # not needed since 
#H_max_converters = (converter_height * 5) - converter_height + 1
w_bat, fixed_h_bat, eff_bat = 651, 1.35, 0.9

# Paths 
POS_XLSX = r"C:\Users\fmylonopoulos\OneDrive - Delft University of Technology\Desktop\THESIS\chapter4_stability_extra\positions.xlsx"
profile_path = r"C:\Users\fmylonopoulos\OneDrive - Delft University of Technology\Desktop\THESIS\chapter4_stability_extra\Power_Profile.xlsx"

# Load profile (demand already includes efficiencies of components such as conv, inv, motor, gb)
profile_data = pd.read_excel(profile_path)
time = profile_data.iloc[:, 0] / 3600.0  # h
demand = profile_data.iloc[:, 2]
ntime = len(time)


# Optimization model

model = Model("Retrofit_Cost_Stability")

# Decision: counts
Nfc  = model.addVar(vtype="I", lb=NFC_MIN,  ub=NFC_MAX,  name="Nfc")
Nbat = model.addVar(vtype="I", lb=NBAT_MIN, ub=NBAT_MAX, name="Nbat")









# Power & SoC variables
Pfc   = {k: model.addVar(lb=Pfc_min,          ub=Pfc_max,          name=f"Pfc_{k}")   for k in range(ntime)}
Pbatt = {k: model.addVar(lb=Pbatt_max_charge, ub=Pbatt_max_disch,  name=f"Pbatt_{k}") for k in range(ntime)}
SoC   = {k: model.addVar(lb=SoCmin,           ub=SoCmax,           name=f"SoC_{k}")   for k in range(ntime)}

FuelConsTotal = model.addVar(name="FuelConsTotal")

# Initial/final SoC
model.addCons(SoC[0] == SoCinitial)
model.addCons(SoC[ntime - 1] >= SoCinitial)

# SoC constraitns
for k in range(1, ntime):
    model.addCons(SoC[k] == SoC[k-1] - (Sampling_dt * Pbatt[k]) / Ebatt_rated)

# Demand balance per step (kW)
for k in range(ntime):
    model.addCons(Nfc * Pfc[k] + Nbat * Pbatt[k] == demand[k])

# Fuel consumption (kWh to H2 via polynomial)
FuelConsExpr = quicksum(
    Nfc * (a_quadratic * Pfc[k]**2 + b_quadratic * Pfc[k] + c_quadratic) * Sampling_dt * Conversion_coefficient
    for k in range(ntime)
)
model.addCons(FuelConsTotal == FuelConsExpr)

# Tank sizing (volume/weight)
no_trips_before_refueling = 4

margin_tanksize = 1.4
no_tanks = 1
tank_no_cost_factor = 1.0

tank_volume   = model.addVar(name="tank_volume")
tank_weight   = model.addVar(name="tank_weight")
tank_diameter = model.addVar(name="tank_diameter")

model.addCons(tank_volume == margin_tanksize * FuelConsTotal * no_trips_before_refueling * Vol_spec / no_tanks)
model.addCons(tank_weight == margin_tanksize * FuelConsTotal * no_trips_before_refueling * Grav_spec / no_tanks)
model.addCons(tank_diameter * tank_diameter == (4.0 * tank_volume) / (math.pi * Length_tank))
model.addCons(tank_volume * no_tanks <= 212.0)
#model.addCons(tank_volume * no_tanks <= 150)


# Positions (from Excel)

df_fc   = pd.read_excel(POS_XLSX, sheet_name="FuelCells",  usecols=[0,1,2], header=0, decimal=",")
df_conv = pd.read_excel(POS_XLSX, sheet_name="Converters", usecols=[0,1,2], header=0, decimal=",")
df_bat  = pd.read_excel(POS_XLSX, sheet_name="Batteries",  usecols=[0,1,2], header=0, decimal=",")  

df_fc.columns, df_conv.columns, df_bat.columns = ["x","y","z"], ["x","y","z"], ["x","y","z"]
pos_fc   = [(float(r.x), float(r.y), float(r.z)) for r in df_fc.itertuples(index=False)]
pos_conv = [(float(r.x), float(r.y), float(r.z)) for r in df_conv.itertuples(index=False)]
pos_bat  = [(float(r.x), float(r.y), float(r.z)) for r in df_bat.itertuples(index=False)]

Z_BASE_OFFSET_FC, Z_BASE_OFFSET_CONV, Z_BASE_OFFSET_BAT = 0.0, 0.0, 0.0




# Symmetry & stacking 

TOL = 1e-3
def _r(x): return round(float(x), 3)

slot_groups, centerline_fc = {}, []
for p, (x,y,z) in enumerate(pos_fc):
    if abs(y) <= TOL:
        centerline_fc.append(p)
        continue
    key = (_r(x), _r(abs(y)), _r(z))
    slot_groups.setdefault(key, {"pos": [], "neg": []})
    (slot_groups[key]["pos"] if y > 0 else slot_groups[key]["neg"]).append(p)

mirror_pairs_fc, unpaired_fc = [], []
for key, sides in slot_groups.items():
    n = min(len(sides["pos"]), len(sides["neg"]))
    mirror_pairs_fc.extend(zip(sides["neg"][:n], sides["pos"][:n]))
    unpaired_fc.extend(sides["neg"][n:] + sides["pos"][n:])

towers_fc, towers_conv = {}, {}
for p,(x,y,z) in enumerate(pos_fc):
    towers_fc.setdefault((_r(x), _r(y)), []).append((z,p))
for key in towers_fc:
    towers_fc[key].sort(key=lambda t: float(t[0]))

for p,(x,y,z) in enumerate(pos_conv):
    towers_conv.setdefault((_r(x), _r(y)), []).append((z,p))
for key in towers_conv:
    towers_conv[key].sort(key=lambda t: float(t[0]))

# Battery centerline vs off-center sets (for priority rule)
centerline_bat = [p for p,(x,y,z) in enumerate(pos_bat) if abs(y) <= TOL]
offcenter_bat  = [p for p,(x,y,z) in enumerate(pos_bat) if abs(y) >  TOL]

# ==========================
# Discrete assignment variables
# ==========================
P_FC   = range(len(pos_fc))
P_CONV = range(len(pos_conv))
P_BAT  = range(len(pos_bat))




# One binary per slot (no per-unit labels)
y_fc       = {p: model.addVar(vtype="B", name=f"y_fc_{p}")       for p in P_FC}
y_bat      = {s: model.addVar(vtype="B", name=f"y_bat_{s}")      for s in P_BAT}
y_fc_conv  = {q: model.addVar(vtype="B", name=f"y_fcconv_{q}")   for q in P_CONV}
y_bat_conv = {q: model.addVar(vtype="B", name=f"y_batconv_{q}")  for q in P_CONV}

# Exactly Nfc FC slots and Nbat battery slots must be used
model.addCons(quicksum(y_fc[p]  for p in P_FC)  == Nfc)
model.addCons(quicksum(y_bat[s] for s in P_BAT) == Nbat)

# Exactly Nfc FC converters and Nbat battery converters
model.addCons(quicksum(y_fc_conv[q]  for q in P_CONV) == Nfc)
model.addCons(quicksum(y_bat_conv[q] for q in P_CONV) == Nbat)

# Converter exclusivity per slot (either FC or BAT or none)
for q in P_CONV:
    model.addCons(y_fc_conv[q] + y_bat_conv[q] <= 1)





# Battery rule: at least K batteries on the centerline
K = min(3, NBAT_MAX)
if K > 0:
    centerline_bat = [p for p in P_BAT if abs(pos_bat[p][1]) <= 1e-3]
    model.addCons(quicksum(y_bat[p] for p in centerline_bat) >= K)






# Fuel cell transverse symmetry (no centerline use) + tower stacking
for p in centerline_fc:
    model.addCons(y_fc[p] == 0)


# Allow at most one Left/right asymmetry pair if Nfc is odd 
r_vars = []
for m_idx, (p_neg, p_pos) in enumerate(mirror_pairs_fc):
    r = model.addVar(vtype="B", name=f"fc_pair_relax_{m_idx}")
    r_vars.append(r)
    model.addCons(y_fc[p_neg] - y_fc[p_pos] <= r)
    model.addCons(y_fc[p_pos] - y_fc[p_neg] <= r)

unpaired_used = quicksum(y_fc[p] for p in unpaired_fc) if unpaired_fc else 0
q_pairs = model.addVar(vtype="I", lb=0, ub=NFC_MAX // 2, name="pair_count_aux")
is_odd  = model.addVar(vtype="B", name="Nfc_is_odd")
model.addCons(Nfc == 2 * q_pairs + is_odd)
if r_vars or unpaired_fc:
    model.addCons(quicksum(r_vars) + unpaired_used <= is_odd)


# No vertical floating 
for key, zplist in towers_fc.items():
    if len(zplist) <= 1: 
        continue
    for k in range(1, len(zplist)):
        _, p_lower = zplist[k-1]
        _, p_here  = zplist[k]
        model.addCons(y_fc[p_here] <= y_fc[p_lower])

# No vertical floating (Converter towers) – FC and BAT independently
for key, zplist in towers_conv.items():
    if len(zplist) <= 1:
        continue
    for k in range(1, len(zplist)):
        _, q_lower = zplist[k-1]
        _, q_here  = zplist[k]
        model.addCons(y_fc_conv[q_here]  <= y_fc_conv[q_lower])
        model.addCons(y_bat_conv[q_here] <= y_bat_conv[q_lower])






# Ballast options

ballast_options = [
    {"extra_ballast": 0, "extra_ballast_VCG": 0.0, "extra_ballast_LCG": 0.0},

    {"extra_ballast": 2 * 43.658 * 1000, "extra_ballast_VCG": 4.865, "extra_ballast_LCG": 0.349},
    {"extra_ballast": 2 * 30.955 * 1000, "extra_ballast_VCG": 0.508, "extra_ballast_LCG": 20.150},
    {"extra_ballast": 2 * 85.783 * 1000, "extra_ballast_VCG": 0.527, "extra_ballast_LCG": 26.672},   # 
    {"extra_ballast": 2 * 128.150 * 1000, "extra_ballast_VCG": 0.509, "extra_ballast_LCG": 45.100},
    {"extra_ballast": 2 * 111.426 * 1000, "extra_ballast_VCG": 0.518, "extra_ballast_LCG": 65.390},
    {"extra_ballast": 2 * 140.766 * 1000, "extra_ballast_VCG": 4.5, "extra_ballast_LCG": 40.9},
    {"extra_ballast": 2 * 107.204 * 1000, "extra_ballast_VCG": 4.51, "extra_ballast_LCG": 56.943},
    {"extra_ballast": 2 * 69.985 * 1000, "extra_ballast_VCG": 5.109, "extra_ballast_LCG": 69.223},
    {"extra_ballast": 1 * 78.84  * 1000, "extra_ballast_VCG": 3.129, "extra_ballast_LCG": 82.255},  # forepeak

    # two-tank combos 
    {"extra_ballast": (2 * 43.658 + 2 * 30.955) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 0.508 * 30.955) / (43.658 + 30.955),
     "extra_ballast_LCG": (0.349 * 43.658 + 20.150 * 30.955) / (43.658 + 30.955)},

    {"extra_ballast": (2 * 43.658 + 2 * 85.783) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 0.527 * 85.783) / (43.658 + 85.783),
     "extra_ballast_LCG": (0.349 * 43.658 + 26.672 * 85.783) / (43.658 + 85.783)},

    {"extra_ballast": (2 * 43.658 + 2 * 128.150) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 0.509 * 128.150) / (43.658 + 128.150),
     "extra_ballast_LCG": (0.349 * 43.658 + 45.100 * 128.150) / (43.658 + 128.150)},

    {"extra_ballast": (2 * 43.658 + 2 * 111.426) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 0.518 * 111.426) / (43.658 + 111.426),
     "extra_ballast_LCG": (0.349 * 43.658 + 65.390 * 111.426) / (43.658 + 111.426)},

    # -- EXTRA OPTIONS 
    {"extra_ballast": (2 * 43.658 + 2 * 140.766) * 1000,
    "extra_ballast_VCG": (4.865 * 43.658 + 4.5 * 140.766) / (43.658 + 140.766),
     "extra_ballast_LCG": (0.349 * 43.658 + 40.9 * 140.766) / (43.658 + 140.766)},

    {"extra_ballast": (2 * 43.658 + 2 * 107.204) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 4.51 * 107.204) / (43.658 + 107.204),
     "extra_ballast_LCG": (0.349 * 43.658 + 56.943 * 107.204) / (43.658 + 107.204)},

    {"extra_ballast": (2 * 43.658 + 2 * 69.985) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 5.109 * 69.985) / (43.658 + 69.985),
     "extra_ballast_LCG": (0.349 * 43.658 + 69.223 * 69.985) / (43.658 + 69.985)},


    {"extra_ballast": (2 * 43.658 + 78.84) * 1000,
    "extra_ballast_VCG": (4.865 * 43.658 + 3.129 * 78.84) / (43.658 + 78.84),  
     "extra_ballast_LCG": (0.349 * 43.658 + 82.255 * 78.84) / (43.658 + 78.84)},






    {"extra_ballast": (2 * 30.955 + 2 * 85.783) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 0.527 * 85.783) / (30.955 + 85.783),
     "extra_ballast_LCG": (20.150 * 30.955 + 26.672 * 85.783) / (30.955 + 85.783)},

    {"extra_ballast": (2 * 30.955 + 2 * 128.150) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 0.509 * 128.150) / (30.955 + 128.150),
     "extra_ballast_LCG": (20.150 * 30.955 + 45.100 * 128.150) / (30.955 + 128.150)},

    {"extra_ballast": (2 * 30.955 + 2 * 111.426) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 0.518 * 111.426) / (30.955 + 111.426),
     "extra_ballast_LCG": (20.150 * 30.955 + 65.390 * 111.426) / (30.955 + 111.426)},

    {"extra_ballast": (2 * 30.955 + 2 * 140.766) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 4.5 * 140.766) / (30.955 + 140.766),
     "extra_ballast_LCG": (20.150 * 30.955 + 40.9 * 140.766) / (30.955 + 140.766)},

    {"extra_ballast": (2 * 30.955 + 2 * 107.204) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 4.51 * 107.204) / (30.955 + 107.204),
     "extra_ballast_LCG": (20.150 * 30.955 + 56.943 * 107.204) / (30.955 + 107.204)},

    {"extra_ballast": (2 * 30.955 + 2 * 69.985) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 5.109 * 69.985) / (30.955 + 69.985),
     "extra_ballast_LCG": (20.150 * 30.955 + 69.223 * 69.985) / (30.955 + 69.985)},

    
    
    {"extra_ballast": (2 * 30.955 + 78.84) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 3.129 * 78.84) / (30.955 + 78.84),
    "extra_ballast_LCG": (20.150 * 30.955 + 82.255 * 78.84) / (30.955 + 78.84)},





    {"extra_ballast": (2 * 85.783 + 2 * 128.150) * 1000,
     "extra_ballast_VCG": (0.527 * 85.783 + 0.509 * 128.150) / (85.783 + 128.150),
     "extra_ballast_LCG": (26.672 * 85.783 + 45.100 * 128.150) / (85.783 + 128.150)},

    {"extra_ballast": (2 * 85.783 + 2 * 111.426) * 1000,
     "extra_ballast_VCG": (0.527 * 85.783 + 0.518 * 111.426) / (85.783 + 111.426),
     "extra_ballast_LCG": (26.672 * 85.783 + 65.390 * 111.426) / (85.783 + 111.426)},

    {"extra_ballast": (2 * 85.783 + 2 * 140.766) * 1000,
     "extra_ballast_VCG": (0.527 * 85.783 + 4.5 * 140.766) / (85.783 + 140.766),
     "extra_ballast_LCG": (26.672 * 85.783 + 40.9 * 140.766) / (85.783 + 140.766)},

    {"extra_ballast": (2 * 85.783 + 2 * 107.204) * 1000,
     "extra_ballast_VCG": (0.527 * 85.783 + 4.51 * 107.204) / (85.783 + 107.204),
     "extra_ballast_LCG": (26.672 * 85.783 + 56.943 * 107.204) / (85.783 + 107.204)},

    {"extra_ballast": (2 * 85.783 + 2 * 69.985) * 1000,
     "extra_ballast_VCG": (0.527 * 85.783 + 5.109 * 69.985) / (85.783 + 69.985),
     "extra_ballast_LCG": (26.672 * 85.783 + 69.223 * 69.985) / (85.783 + 69.985)},


    {"extra_ballast": (2 * 85.783 + 78.84) * 1000,
     "extra_ballast_VCG": (0.527 * 85.783 + 3.129 * 78.84) / (85.783 + 78.84),  
     "extra_ballast_LCG": (26.672 * 85.783 + 82.255 * 78.84) / (85.783 + 78.84)},





    {"extra_ballast": (2 * 128.150 + 2 * 111.426) * 1000,
     "extra_ballast_VCG": (0.509 * 128.150 + 0.518 * 111.426) / (128.150 + 111.426),
     "extra_ballast_LCG": (45.100 * 128.150 + 65.390 * 111.426) / (128.150 + 111.426)},

    {"extra_ballast": (2 * 128.150 + 2 * 140.766) * 1000,
     "extra_ballast_VCG": (0.509 * 128.150 + 4.5 * 140.766) / (128.150 + 140.766),
     "extra_ballast_LCG": (45.100 * 128.150 + 40.9 * 140.766) / (128.150 + 140.766)},

    {"extra_ballast": (2 * 128.150 + 2 * 107.204) * 1000,
     "extra_ballast_VCG": (0.509 * 128.150 + 4.51 * 107.204) / (128.150 + 107.204),
     "extra_ballast_LCG": (45.100 * 128.150 + 56.943 * 107.204) / (128.150 + 107.204)},

    {"extra_ballast": (2 * 128.150 + 2 * 69.985) * 1000,
     "extra_ballast_VCG": (0.509 * 128.150 + 5.109 * 69.985) / (128.150 + 69.985),
     "extra_ballast_LCG": (45.100 * 128.150 + 69.223 * 69.985) / (128.150 + 69.985)},

    {"extra_ballast": (2 * 128.150 + 78.84) * 1000,
     "extra_ballast_VCG": (0.509 * 128.150 + 3.129 * 78.84) / (128.150 + 78.84),
     "extra_ballast_LCG": (45.100 * 128.150 + 82.255 * 78.84) / (128.150 + 78.84)},

    # Three-tank combinations
    {"extra_ballast": (2 * 43.658 + 2 * 30.955 + 2*69.985) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 0.508 * 30.955 + 5.109*69.985) / (43.658 + 30.955 + 69.985),
     "extra_ballast_LCG": (0.349 * 43.658 + 20.150 * 30.955 + 69.223 * 69.985) / (43.658 + 30.955 + 69.985)},



    {"extra_ballast": (2 * 43.658 + 2 * 30.955 + 78.84) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658 + 0.508 * 30.955 + 3.129*78.84) / (43.658 + 30.955 + 78.84),
     "extra_ballast_LCG": (0.349 * 43.658 + 20.150 * 30.955 + 82.255 * 78.84) / (43.658 + 30.955 + 78.84)},

    {"extra_ballast": (2 * 43.658 + 2*69.985 + 78.84) * 1000,
     "extra_ballast_VCG": (4.865 * 43.658  + 5.109*69.985 + 3.129*78.84) / (43.658 + 69.985 + 78.84),
     "extra_ballast_LCG": (0.349 * 43.658 + 69.223 * 69.985 + 82.255 * 78.84) / (43.658 + 69.985 + 78.84)},

    {"extra_ballast": (2 * 30.955 + 2*69.985 + 78.84) * 1000,
     "extra_ballast_VCG": (0.508 * 30.955 + 5.109*69.985 + 3.129*78.84) / (30.955 + 69.985 + 78.84),
     "extra_ballast_LCG": (20.150 * 30.955 + 69.223 * 69.985 + 82.255 * 78.84) / (30.955 + 69.985 + 78.84)},
]


ballast_selection = {i: model.addVar(vtype="B", name=f"ballast_sel_{i}") for i in range(len(ballast_options))}
model.addCons(quicksum(ballast_selection.values()) == 1)

extra_ballast      = model.addVar(name="extra_ballast")
extra_ballast_VCG  = model.addVar(name="extra_ballast_VCG")
extra_ballast_LCG  = model.addVar(name="extra_ballast_LCG")

model.addCons(extra_ballast     == quicksum(ballast_selection[i]*ballast_options[i]["extra_ballast"]     for i in range(len(ballast_options))))
model.addCons(extra_ballast_VCG == quicksum(ballast_selection[i]*ballast_options[i]["extra_ballast_VCG"] for i in range(len(ballast_options))))
model.addCons(extra_ballast_LCG == quicksum(ballast_selection[i]*ballast_options[i]["extra_ballast_LCG"] for i in range(len(ballast_options))))



# DWT adjustments (no fuel here - fuel separate INCLUDED)
adjusted_DWT_weight = (DWT_loaded_original - DWT_removal_weight
                       + extra_ballast - DWT_ballast_removal_homogeneous)

adjusted_DWT_KG_contribution = (
    (DWT_loaded_original * KG_DWT_loaded_original
     - DWT_removal_weight * KG_DWT_removal
     + extra_ballast * extra_ballast_VCG
     - DWT_ballast_removal_homogeneous * KG_DWT_ballast_removal_homogeneous)
    / adjusted_DWT_weight
)

# Auxiliary vrbl for reporting 
adj_DWT_KG_var = model.addVar(name="adj_DWT_KG_var")
model.addCons(adj_DWT_KG_var == adjusted_DWT_KG_contribution)


# Fuel mass & KG 
fuel_weight = FuelConsTotal * no_trips_before_refueling
KG_hydrogen_fuel = Height_tank_above_keel + 0.6 * tank_diameter / 2.0

# Total added equipment mass
total_added_weight = (
    Nfc * w_fc + Nbat * w_bat
    + (Nfc + Nbat) * converter_weight
    + n_motor * w_motor
    + n_inverter * w_inverter
    + n_gearbox * w_gearbox
    + tank_weight * no_tanks
)


# AFT ENGINE rRoom bulkhead
aft_ER_AP = 4.2
AFT_ER_AP = aft_ER_AP



fc_KG_expr = quicksum(
    w_fc * ((Z_BASE_OFFSET_FC + pos_fc[p][2]) + fixed_h_fc/2.0) * y_fc[p]
    for p in P_FC
)

conv_KG_expr = quicksum(
    converter_weight * ((Z_BASE_OFFSET_CONV + pos_conv[q][2]) + converter_height/2.0) *
    (y_fc_conv[q] + y_bat_conv[q]) for q in P_CONV
)

bat_KG_expr = quicksum(
    w_bat * ((Z_BASE_OFFSET_BAT + pos_bat[s][2]) + fixed_h_bat/2.0) * y_bat[s]
    for s in P_BAT
)


fixed_equip_KG_expr = (
    n_motor    * w_motor    * (h_motor/2.0    + 1.0) +
    n_inverter * w_inverter * (h_inverter/2.0 + 1.0) +
    n_gearbox  * w_gearbox  * (h_gearbox/2.0  + 1.0) +
    tank_weight * no_tanks * (Height_tank_above_keel + tank_diameter/2.0)
)

total_added_KG_moment = fc_KG_expr + conv_KG_expr + bat_KG_expr + fixed_equip_KG_expr


# Total weights 
Original_total_weight = 4835.844 * 1000




# --- margin as a separate mass at specified z/x  - structural bulkheads and other auxiliary systems 
MARGIN_FRAC  = 0.02

MARGIN_Z_KG  = 8

MARGIN_X_LCG = (AFT_ER_AP + 8)
margin_mass  = MARGIN_FRAC * original_lightship_weight






# lightship 
lightship_weight_nom = (
    original_lightship_weight - engine_weight
    + n_motor * w_motor
    + n_gearbox * w_gearbox
    + n_inverter * w_inverter
    + converter_weight * (Nfc + Nbat)
    + w_bat * Nbat
    + w_fc * Nfc
    + tank_weight * no_tanks
)

# DWT includes fuel (weight side), moments handled below
DWT_weight_expr = (
    DWT_loaded_original - DWT_removal_weight
    + extra_ballast - DWT_ballast_removal_homogeneous
    + fuel_weight
)


W_nom = lightship_weight_nom + margin_mass + DWT_weight_expr
W_tot = W_nom  

# Displacement variable 
displacement = model.addVar(name="displacement")
model.addCons(displacement == W_tot)

# 5% cap (limit for Dipslcmaent)
WEIGHT_CAP_KG = 1.05 * Original_total_weight
model.addCons(W_tot <= WEIGHT_CAP_KG, name="weight_cap_5pct")

# Free surface moment
FSM_total_original_loaded = 96.51  # ton·m
FSM_HFO_loaded            = 30.47  # ton·m
FSM_increase_factor       = 1.0
FSM_extra_ballast         = 0.0
rho_LH2 = 0.07  # ton/m^3

FSM_tank = model.addVar(name="FSM_tank")
FSM_total_corrected = model.addVar(name="FSM_total_corrected")

I_tank_expr = ((tank_diameter**3) * Length_tank)/12.0
FSM_tank_expr = rho_LH2 * I_tank_expr

FSM_ballast_removed_front = 38.313  # ton·m (removed 28 t at ~40 m)

FSM_total_corrected_expr = (FSM_extra_ballast
                            - FSM_HFO_loaded
                            + FSM_total_original_loaded * FSM_increase_factor
                            + FSM_tank_expr * no_tanks
                            - FSM_ballast_removed_front) * 1000.0  # kg·m

model.addCons(FSM_tank == FSM_tank_expr)
model.addCons(FSM_total_corrected == FSM_total_corrected_expr)

GG_correction = FSM_total_corrected / W_tot

# KG (with margin & fuel)
new_KG = model.addVar(name="new_KG")

model.addCons(new_KG == (
    (original_lightship_weight*KG_original_lightship
     - engine_weight*(z_engine + engine_height/2.0)
     + adjusted_DWT_weight*adjusted_DWT_KG_contribution
     + total_added_KG_moment
     + fuel_weight*KG_hydrogen_fuel
     + margin_mass*MARGIN_Z_KG)  / W_tot
) + GG_correction)

# KG limit based on booklet
KG_MAX_LIMIT = 5.044
model.addCons(new_KG <= KG_MAX_LIMIT, name="KG_upper_limit")

# Longitudinal CG (moments)
original_lightship_LCG = 36.305
engine_LCG = 10.2

# Moments from assignments (x = AFT_ER_AP + slot_x)
fc_L_moment = quicksum(
    w_fc * (AFT_ER_AP + pos_fc[p][0]) * y_fc[p] for p in P_FC
)

conv_L_moment = quicksum(
    converter_weight * (AFT_ER_AP + pos_conv[q][0]) * (y_fc_conv[q] + y_bat_conv[q])
    for q in P_CONV
)

bat_L_moment = quicksum(
    w_bat * (AFT_ER_AP + pos_bat[s][0]) * y_bat[s] for s in P_BAT
)


tank_L_moment = (tank_weight * no_tanks) * (15.0 * 0.6 + tank_diameter / 2.0)

# sensitivity for tank placed at the start of the first cargo hold
#tank_L_moment = (tank_weight * no_tanks) * (25.0 * 0.6 + tank_diameter / 2.0)






Motor_L_moment    = w_motor    * n_motor    * (AFT_ER_AP + 4.22)
Gearbox_L_moment  = w_gearbox  * n_gearbox  * (AFT_ER_AP + 1.56)
Inverter_L_moment = w_inverter * n_inverter * (AFT_ER_AP + 5.02)

lightship_moment_expr = (
    (original_lightship_weight * original_lightship_LCG)
    - engine_weight * engine_LCG
    + fc_L_moment
    + conv_L_moment
    + bat_L_moment
    + tank_L_moment
    + Motor_L_moment
    + Gearbox_L_moment
    + Inverter_L_moment
    + margin_mass * MARGIN_X_LCG
)

# Ligthship weight used on the LCG side (incl. margin mass)
lightship_weight_expr = lightship_weight_nom + margin_mass


# DWT moment (+fuel here)
DWT_original_LCG = 42.103
DWT_removal_LCG  = 21.406

DWT_moment_expr = (
    (DWT_loaded_original * DWT_original_LCG)
    - (DWT_removal_weight * DWT_removal_LCG)
    + (extra_ballast * extra_ballast_LCG)
    - (DWT_ballast_removal_homogeneous * LCG_DWT_ballast_removal_homogeneous)
    + fuel_weight * (15.0 * 0.6 + tank_diameter / 2.0)
    #+ fuel_weight * (25.0 * 0.6 + tank_diameter / 2.0)  # for sensitivity when the hydrogen tank is placed at the start of the first cargo hold.
)

total_weight_expr = lightship_weight_expr + DWT_weight_expr  # equals W_tot
total_moment_expr = lightship_moment_expr + DWT_moment_expr

new_total_LCG = model.addVar(name="new_total_LCG")
model.addCons(displacement == total_weight_expr)
model.addCons(new_total_LCG == total_moment_expr / displacement)

# Hydrostatic interpolation - trim data
new_trim_data = [
    {"Displacement": 4576.77 * 1000, "MCT": 63.1,  "LCB": 41.518, "KM_transverse": 5.358},
    {"Displacement": 4597.04 * 1000, "MCT": 63.20, "LCB": 41.499, "KM_transverse": 5.359},
    {"Displacement": 4617.33 * 1000, "MCT": 63.30, "LCB": 41.480, "KM_transverse": 5.360},
    {"Displacement": 4637.62 * 1000, "MCT": 63.38, "LCB": 41.461, "KM_transverse": 5.361},
    {"Displacement": 4657.92 * 1000, "MCT": 63.46, "LCB": 41.442, "KM_transverse": 5.363},
    {"Displacement": 4678.22 * 1000, "MCT": 63.55, "LCB": 41.423, "KM_transverse": 5.364},
    {"Displacement": 4698.54 * 1000, "MCT": 63.63, "LCB": 41.404, "KM_transverse": 5.365},
    {"Displacement": 4718.86 * 1000, "MCT": 63.71, "LCB": 41.386, "KM_transverse": 5.367},
    {"Displacement": 4739.19 * 1000, "MCT": 63.76, "LCB": 41.368, "KM_transverse": 5.370},
    {"Displacement": 4759.58 * 1000, "MCT": 63.90, "LCB": 41.349, "KM_transverse": 5.373},
    {"Displacement": 4779.97 * 1000, "MCT": 64.05, "LCB": 41.331, "KM_transverse": 5.375},
    {"Displacement": 4800.37 * 1000, "MCT": 64.21, "LCB": 41.312, "KM_transverse": 5.377},
    {"Displacement": 4811.60 * 1000, "MCT": 64.29, "LCB": 41.302, "KM_transverse": 5.378},
    {"Displacement": 4820.79 * 1000, "MCT": 64.36, "LCB": 41.294, "KM_transverse": 5.379},
    {"Displacement": 4841.21 * 1000, "MCT": 64.52, "LCB": 41.276, "KM_transverse": 5.380},
    {"Displacement": 4861.63 * 1000, "MCT": 64.67, "LCB": 41.258, "KM_transverse": 5.382},
    {"Displacement": 4882.07 * 1000, "MCT": 64.83, "LCB": 41.241, "KM_transverse": 5.384},
    {"Displacement": 4902.51 * 1000, "MCT": 64.91, "LCB": 41.223, "KM_transverse": 5.386},
    {"Displacement": 4922.97 * 1000, "MCT": 65.01, "LCB": 41.206, "KM_transverse": 5.387},
    {"Displacement": 4943.43 * 1000, "MCT": 65.09, "LCB": 41.189, "KM_transverse": 5.389},
    {"Displacement": 4963.90 * 1000, "MCT": 65.17, "LCB": 41.172, "KM_transverse": 5.391},
    {"Displacement": 4984.37 * 1000, "MCT": 65.25, "LCB": 41.155, "KM_transverse": 5.393},
    {"Displacement": 5004.86 * 1000, "MCT": 65.33, "LCB": 41.138, "KM_transverse": 5.394},
    {"Displacement": 5025.35 * 1000, "MCT": 65.41, "LCB": 41.121, "KM_transverse": 5.397},
    {"Displacement": 5045.85 * 1000, "MCT": 65.49, "LCB": 41.105, "KM_transverse": 5.399},
    {"Displacement": 5066.35 * 1000, "MCT": 65.56, "LCB": 41.089, "KM_transverse": 5.401},
    {"Displacement": 5086.87 * 1000, "MCT": 65.65, "LCB": 41.073, "KM_transverse": 5.403},
    {"Displacement": 5107.41 * 1000, "MCT": 65.71, "LCB": 41.057, "KM_transverse": 5.408},
    {"Displacement": 5127.98 * 1000, "MCT": 65.85, "LCB": 41.041, "KM_transverse": 5.411},
    {"Displacement": 5148.55 * 1000, "MCT": 65.97, "LCB": 41.025, "KM_transverse": 5.413},
    {"Displacement": 5169.13 * 1000, "MCT": 66.10, "LCB": 41.009, "KM_transverse": 5.416},
    {"Displacement": 5189.72 * 1000, "MCT": 66.25, "LCB": 40.994, "KM_transverse": 5.418},
    {"Displacement": 5210.32 * 1000, "MCT": 66.38, "LCB": 40.978, "KM_transverse": 5.420},
    {"Displacement": 5230.93 * 1000, "MCT": 66.51, "LCB": 40.963, "KM_transverse": 5.423},
    {"Displacement": 5251.54 * 1000, "MCT": 66.63, "LCB": 40.948, "KM_transverse": 5.425},
    {"Displacement": 5272.17 * 1000, "MCT": 66.72, "LCB": 40.933, "KM_transverse": 5.428},
    {"Displacement": 5292.82 * 1000, "MCT": 66.83, "LCB": 40.918, "KM_transverse": 5.432},
    {"Displacement": 5313.47 * 1000, "MCT": 66.94, "LCB": 40.903, "KM_transverse": 5.435},
]

MCT_i = model.addVar(name="MCT_interpolated")
LCB_i = model.addVar(name="LCB_interpolated")
KM_i  = model.addVar(name="KM_transverse_interpolated")
new_trim = model.addVar(lb=-0.48, ub=-0.38, name="new_trim")

range_sel = {i: model.addVar(vtype="B", name=f"range_sel_{i}") for i in range(len(new_trim_data)-1)}
model.addCons(quicksum(range_sel.values()) == 1)

BIG = 1e6
for i in range(len(new_trim_data)-1):
    lo, up = new_trim_data[i], new_trim_data[i+1]
    dD = up["Displacement"] - lo["Displacement"]
    mct_slope = (up["MCT"] - lo["MCT"]) / dD
    lcb_slope = (up["LCB"] - lo["LCB"]) / dD
    km_slope  = (up["KM_transverse"] - lo["KM_transverse"]) / dD

    model.addCons(MCT_i >= lo["MCT"] + mct_slope * (displacement - lo["Displacement"]) - (1 - range_sel[i]) * BIG)
    model.addCons(MCT_i <= lo["MCT"] + mct_slope * (displacement - lo["Displacement"]) + (1 - range_sel[i]) * BIG)

    model.addCons(LCB_i >= lo["LCB"] + lcb_slope * (displacement - lo["Displacement"]) - (1 - range_sel[i]) * BIG)
    model.addCons(LCB_i <= lo["LCB"] + lcb_slope * (displacement - lo["Displacement"]) + (1 - range_sel[i]) * BIG)

    model.addCons(KM_i  >= lo["KM_transverse"] + km_slope  * (displacement - lo["Displacement"]) - (1 - range_sel[i]) * BIG)
    model.addCons(KM_i  <= lo["KM_transverse"] + km_slope  * (displacement - lo["Displacement"]) + (1 - range_sel[i]) * BIG)

    model.addCons(displacement >= lo["Displacement"] - (1 - range_sel[i]) * BIG)
    model.addCons(displacement <= up["Displacement"] + (1 - range_sel[i]) * BIG)

# Trim equation
model.addCons(new_trim == (((new_total_LCG - LCB_i) * (displacement / 1000.0)) / (MCT_i * 100.0)))

# GM constraint
model.addCons(KM_i - new_KG >= GM_min)


# KN*sin table & GZ 
theta_degrees = [0, 2, 5, 10, 12, 15, 20, 30, 40, 50, 60]
angles_rad = [math.radians(t) for t in theta_degrees]

KN_sin_data = [
    {"Displacement": 4600 * 1000, "KN*sin": [0.0, 0.187, 0.468, 0.937, 1.125, 1.407, 1.883, 2.835, 3.716, 4.424, 4.822]},
    {"Displacement": 4620 * 1000, "KN*sin": [0.0, 0.187, 0.468, 0.937, 1.125, 1.407, 1.883, 2.833, 3.714, 4.421, 4.819]},
    {"Displacement": 4640 * 1000, "KN*sin": [0.0, 0.187, 0.468, 0.937, 1.125, 1.408, 1.883, 2.830, 3.711, 4.417, 4.816]},
    {"Displacement": 4660 * 1000, "KN*sin": [0.0, 0.187, 0.468, 0.937, 1.125, 1.408, 1.884, 2.828, 3.708, 4.414, 4.813]},
    {"Displacement": 4680 * 1000, "KN*sin": [0.0, 0.187, 0.468, 0.937, 1.125, 1.408, 1.884, 2.826, 3.706, 4.410, 4.809]},
    {"Displacement": 4700 * 1000, "KN*sin": [0.0, 0.187, 0.468, 0.938, 1.126, 1.408, 1.884, 2.823, 3.703, 4.406, 4.806]},
    {"Displacement": 4720 * 1000, "KN*sin": [0.0, 0.187, 0.469, 0.938, 1.126, 1.409, 1.884, 2.821, 3.701, 4.403, 4.803]},
    {"Displacement": 4740 * 1000, "KN*sin": [0.0, 0.187, 0.469, 0.938, 1.126, 1.409, 1.885, 2.819, 3.698, 4.399, 4.799]},
    {"Displacement": 4760 * 1000, "KN*sin": [0.0, 0.188, 0.469, 0.938, 1.126, 1.409, 1.885, 2.817, 3.695, 4.395, 4.796]},
    {"Displacement": 4780 * 1000, "KN*sin": [0.0, 0.188, 0.469, 0.939, 1.127, 1.41, 1.885, 2.815, 3.692, 4.391, 4.792]},
    {"Displacement": 4800 * 1000, "KN*sin": [0.0, 0.188, 0.469, 0.939, 1.127, 1.41, 1.886, 2.813, 3.689, 4.387, 4.789]},
    {"Displacement": 4820 * 1000, "KN*sin": [0.0, 0.188, 0.469, 0.939, 1.127, 1.41, 1.886, 2.811, 3.687, 4.383, 4.785]},
    {"Displacement": 4840 * 1000, "KN*sin": [0.0, 0.188, 0.469, 0.94, 1.128, 1.41, 1.886, 2.808, 3.684, 4.379, 4.782]},
    {"Displacement": 4860 * 1000, "KN*sin": [0.0, 0.188, 0.47, 0.94, 1.128, 1.411, 1.887, 2.806, 3.681, 4.375, 4.778]},
    {"Displacement": 4880 * 1000, "KN*sin": [0.0, 0.188, 0.47, 0.94, 1.128, 1.411, 1.887, 2.804, 3.678, 4.371, 4.775]},
    {"Displacement": 4900 * 1000, "KN*sin": [0.0, 0.188, 0.470, 0.940, 1.129, 1.412, 1.888, 2.803, 3.675, 4.367, 4.771]},
    {"Displacement": 4920 * 1000, "KN*sin": [0.0, 0.188, 0.470, 0.941, 1.129, 1.412, 1.888, 2.801, 3.672, 4.362, 4.767]},
    {"Displacement": 4940 * 1000, "KN*sin": [0.0, 0.188, 0.470, 0.941, 1.129, 1.412, 1.889, 2.799, 3.669, 4.358, 4.764]},
    {"Displacement": 4960 * 1000, "KN*sin": [0.0, 0.188, 0.471, 0.941, 1.130, 1.413, 1.889, 2.797, 3.666, 4.354, 4.760]},
    {"Displacement": 4980 * 1000, "KN*sin": [0.0, 0.188, 0.471, 0.942, 1.130, 1.413, 1.890, 2.795, 3.663, 4.350, 4.756]},
    {"Displacement": 5000 * 1000, "KN*sin": [0.0, 0.188, 0.471, 0.942, 1.130, 1.414, 1.890, 2.793, 3.660, 4.345, 4.753]},
    {"Displacement": 5020 * 1000, "KN*sin": [0.0, 0.188, 0.471, 0.942, 1.131, 1.414, 1.891, 2.792, 3.657, 4.341, 4.749]},
    {"Displacement": 5040 * 1000, "KN*sin": [0.0, 0.188, 0.471, 0.942, 1.131, 1.415, 1.891, 2.790, 3.654, 4.336, 4.745]},
    {"Displacement": 5060 * 1000, "KN*sin": [0.0, 0.189, 0.471, 0.943, 1.131, 1.415, 1.892, 2.788, 3.650, 4.332, 4.741]},
    {"Displacement": 5080 * 1000, "KN*sin": [0.0, 0.189, 0.472, 0.943, 1.132, 1.416, 1.893, 2.787, 3.647, 4.327, 4.737]},
    {"Displacement": 5100 * 1000, "KN*sin": [0.0, 0.189, 0.472, 0.943, 1.132, 1.416, 1.893, 2.785, 3.644, 4.323, 4.734]},
    {"Displacement": 5120 * 1000, "KN*sin": [0.0, 0.189, 0.472, 0.944, 1.133, 1.417, 1.894, 2.783, 3.641, 4.318, 4.730]},
    {"Displacement": 5140 * 1000, "KN*sin": [0.0, 0.189, 0.472, 0.944, 1.133, 1.417, 1.895, 2.782, 3.638, 4.314, 4.726]},
    {"Displacement": 5160 * 1000, "KN*sin": [0.0, 0.189, 0.473, 0.945, 1.133, 1.418, 1.895, 2.780, 3.634, 4.309, 4.722]},
    {"Displacement": 5180 * 1000, "KN*sin": [0.0, 0.189, 0.473, 0.945, 1.134, 1.418, 1.896, 2.779, 3.631, 4.305, 4.718]},
    {"Displacement": 5200 * 1000, "KN*sin": [0.0, 0.189, 0.473, 0.945, 1.134, 1.419, 1.897, 2.777, 3.628, 4.300, 4.714]},
    {"Displacement": 5220 * 1000, "KN*sin": [0.0, 0.189, 0.473, 0.946, 1.135, 1.419, 1.897, 2.776, 3.625, 4.295, 4.710]},
    {"Displacement": 5240 * 1000, "KN*sin": [0.0, 0.189, 0.473, 0.946, 1.135, 1.420, 1.898, 2.775, 3.621, 4.291, 4.706]},
    {"Displacement": 5260 * 1000, "KN*sin": [0.0, 0.189, 0.474, 0.946, 1.136, 1.421, 1.899, 2.773, 3.618, 4.286, 4.702]},
    {"Displacement": 5280 * 1000, "KN*sin": [0.0, 0.190, 0.474, 0.947, 1.136, 1.421, 1.900, 2.772, 3.615, 4.281, 4.698]},
]

def interp_kn_sin(disp, theta_deg):
    idx = None
    for i in range(len(KN_sin_data)-1):
        if KN_sin_data[i]["Displacement"] <= disp <= KN_sin_data[i+1]["Displacement"]:
            idx = i; break
    j = theta_degrees.index(theta_deg)
    if idx is None:
        if disp < KN_sin_data[0]["Displacement"]:
            return KN_sin_data[0]["KN*sin"][j]
        else:
            return KN_sin_data[-1]["KN*sin"][j]
    lo, up = KN_sin_data[idx], KN_sin_data[idx+1]
    dD = up["Displacement"] - lo["Displacement"]
    k_lo, k_up = lo["KN*sin"][j], up["KN*sin"][j]
    return k_lo + (k_up - k_lo) * ((disp - lo["Displacement"]) / dD)


# COST MODEL
fuel_cons_increase = 1.0 
FuelConsTotal_adjusted = model.addVar(name="FuelConsTotal_adjusted")
model.addCons(FuelConsTotal_adjusted == FuelConsTotal * fuel_cons_increase)

CAPEX_expr = (
    Nfc * Pfc_rated * Cost_fc +
    Nbat * Ebatt_rated * Cost_bat +
    Cost_LH2_tank * margin_tanksize * FuelConsTotal_adjusted * no_trips_before_refueling * tank_no_cost_factor +
    Nfc * Pfc_rated * Cost_converters +    # FC converters
    Nbat * Ebatt_rated * Cost_converters + # BAT converters
    n_motor * motor_power * Cost_motors +
    n_inverter * inverter_power * Cost_converters +
    n_gearbox * Cost_gearbox
)

NPV_opex_terms = []
d = 1.0250
boil_off_rate = 0.008

FC_base = FuelConsTotal_adjusted * annual_trips
FC_year = FC_base

for t in range(1, years+1):
    # -- consume used during year t
    FC_boil_off = FC_year * boil_off_rate
    FC_year_used = (FC_year + FC_boil_off)*d
    disc_fuel  = (FC_year_used * cost_hydrogen) / (1 + interest_rate)**t
    repl_fc    = (Nfc * Pfc_rated * Cost_fuelcell_replace) / (1 + interest_rate)**t if t in fuelcell_replacement_years else 0
    repl_ba    = (Nbat * Ebatt_rated * Cost_batt_replace)     / (1 + interest_rate)**t if t in battery_replacement_years      else 0
    NPV_opex_terms.append(disc_fuel + repl_fc + repl_ba)

# next year baseline reset after replacemet year
    FC_year = FC_year_used
    if t in fuelcell_replacement_years:
        FC_year = FC_base


NPV_opex_expr = quicksum(NPV_opex_terms)


Annual_Maintenance_Cost = (
    Cfc_mainten * Nfc * Pfc_rated +
    Cbat_mainten * Nbat * Ebatt_rated +
    Cconverter_mainten * (Nfc * Pfc_rated + Nbat * Ebatt_rated) +
    Cmotor_mainten * n_motor * motor_power +
    Cconverter_mainten * n_inverter * inverter_power
)
NPV_maintenance_expr = quicksum(Annual_Maintenance_Cost / (1 + interest_rate)**t for t in range(1, years+1))

NPV_total_expr = CAPEX_expr + NPV_opex_expr + NPV_maintenance_expr

aux_variable = model.addVar(name="NPV_total_aux")
model.addCons(aux_variable == NPV_total_expr)
model.addCons(aux_variable <= 50000000)  

model.setObjective(aux_variable, "minimize")

# Solve
model.setParam('parallel/maxnthreads', 12)
#model.setParam("limits/gap", 0.0002)   
#model.setParam("limits/gap", 0.0001)
#model.setParam("limits/time", 300)   
model.optimize()

status = model.getStatus()
best = model.getBestSol()
print(f"\nSolve status: {status}")

def V(x):
    return model.getSolVal(best, x) if best is not None else float('nan')

# Reporting

# Installed units

print("\n--- Installed units ---")
Nfc_val  = int(round(V(Nfc)))
Nbat_val = int(round(V(Nbat)))
print(f"Nfc  (count) = {Nfc_val}")
print(f"Nbat (count) = {Nbat_val}")

fc_slots   = [p for p in P_FC   if V(y_fc[p]) > 0.5]
bat_slots  = [s for s in P_BAT  if V(y_bat[s]) > 0.5]
fc_cslots  = [q for q in P_CONV if V(y_fc_conv[q])  > 0.5]
bat_cslots = [q for q in P_CONV if V(y_bat_conv[q]) > 0.5]

print(f"Assigned FC slots = {len(fc_slots)} (must equal Nfc)")
print(f"Assigned BAT slots = {len(bat_slots)} (must equal Nbat)")

print("\n--- FC placements ---")
for p in fc_slots:
    x,y,z = pos_fc[p]
    print(f"FC @ slot {p:02d}  ->  x={x:.3f} m, y={y:.3f} m, z={z:.3f} m")

print("\n--- Battery placements ---")
for s in bat_slots:
    x,y,z = pos_bat[s]
    print(f"BAT @ slot {s:02d} ->  x={x:.3f} m, y={y:.3f} m, z={z:.3f} m")

print("\n--- Converter placements (FC side) ---")
for q in fc_cslots:
    x,y,z = pos_conv[q]
    print(f"FC CONV @ slot {q:02d}  ->  x={x:.3f} m, y={y:.3f} m, z={z:.3f} m")

print("\n--- Converter placements (BAT side) ---")
for q in bat_cslots:
    x,y,z = pos_conv[q]
    print(f"BAT CONV @ slot {q:02d} ->  x={x:.3f} m, y={y:.3f} m, z={z:.3f} m")


# Stability summary
disp_val = V(displacement)
KM_val   = V(KM_i)
KG_val   = V(new_KG)
GM_val   = KM_val - KG_val
LCG_val  = V(new_total_LCG)
trim_val = V(new_trim)

print("\n--- Stability summary ---")
print(f"Displacement [kg]                    : {disp_val:,.1f}")
print(f"Weight cap [kg] (≤ 1.05×{Original_total_weight:,.0f}) : {WEIGHT_CAP_KG:,.0f}")
print(f"Weight cap check                     : {'OK' if disp_val <= WEIGHT_CAP_KG + 1e-6 else 'VIOLATION'}")
print(f"New KG [m] (≤ {KG_MAX_LIMIT})        : {KG_val:.4f}  -> {'OK' if KG_val <= KG_MAX_LIMIT + 1e-6 else 'VIOLATION'}")
print(f"KM (interp) [m]                      : {KM_val:.4f}")
print(f"GM = KM - KG [m] (≥ {GM_min})        : {GM_val:.4f}  -> {'OK' if GM_val >= GM_min - 1e-6 else 'VIOLATION'}")
print(f"Trim [m]                             : {trim_val:.4f}")

# Ballast 
chosen_ballast_idx = None
for i in range(len(ballast_options)):
    if V(ballast_selection[i]) > 0.5:
        chosen_ballast_idx = i
        break
print("\n--- Ballast selection ---")
print(f"Chosen ballast option index: {chosen_ballast_idx}")
print(f"Extra ballast [kg]: {V(extra_ballast):,.1f}")
print(f"  VCG [m]: {V(extra_ballast_VCG):.3f}  |  LCG [m]: {V(extra_ballast_LCG):.3f}")

# GZ curve
KN_vals = {th: interp_kn_sin(disp_val, th) for th in theta_degrees}
GZ_vals = {th: KN_vals[th] - KG_val * math.sin(math.radians(th)) for th in theta_degrees}

print("\nKN*sin (m):")
for th in theta_degrees:
    print(f"  {th:>2}° : {KN_vals[th]:.4f}")

print("\nGZ (m):")
for th in theta_degrees:
    print(f"  {th:>2}° : {GZ_vals[th]:.4f}")

# Areas under GZ
area_up_to_30 = 0.5 * sum(
    (GZ_vals[theta_degrees[i]] + GZ_vals[theta_degrees[i+1]]) * (angles_rad[i+1] - angles_rad[i])
    for i in range(len(theta_degrees)-1) if theta_degrees[i+1] <= 30
)
area_up_to_40 = 0.5 * sum(
    (GZ_vals[theta_degrees[i]] + GZ_vals[theta_degrees[i+1]]) * (angles_rad[i+1] - angles_rad[i])
    for i in range(len(theta_degrees)-1) if theta_degrees[i+1] <= 40
)
area_30_40 = area_up_to_40 - area_up_to_30

max_GZ_theta = max(GZ_vals, key=GZ_vals.get)
max_GZ_value = GZ_vals[max_GZ_theta]

print(f"\nArea under GZ up to 30°: {area_up_to_30:.4f} rad·m")
print(f"Area under GZ up to 40°: {area_up_to_40:.4f} rad·m")
print(f"Area 30°–40°:            {area_30_40:.4f} rad·m")
print(f"Max GZ: {max_GZ_value:.4f} m at φ = {max_GZ_theta}°")

# Cost summary
print("\n--- Cost summary (NPV) ---")
print(f"CAPEX [$]                     : {V(CAPEX_expr):,.0f}")
print(f"NPV OPEX [$]                  : {V(NPV_opex_expr):,.0f}")
print(f"NPV Maintenance [$]           : {V(NPV_maintenance_expr):,.0f}")
print(f"Total NPV [$]                 : {V(aux_variable):,.0f}")



#Year-by-year cost breakdown

if best is None:
    print("\nNo solution found; annual breakdown not available.")
else:
    
    def SV(x): return model.getSolVal(best, x)

    
    Nfc_val   = SV(Nfc)
    Nbat_val  = SV(Nbat)
    FC_base   = SV(FuelConsTotal_adjusted) * annual_trips  # kg H2 / year just afterr reset
    ir        = interest_rate

    # Annual maintenance (same each year, then discounted)
    annual_maint = (
        Cfc_mainten * Nfc_val * Pfc_rated +
        Cbat_mainten * Nbat_val * Ebatt_rated +
        Cconverter_mainten * (Nfc_val * Pfc_rated + Nbat_val * Ebatt_rated) +
        Cmotor_mainten * n_motor * motor_power +
        Cconverter_mainten * n_inverter * inverter_power
    )

    try:
        batt_repl_years = set(battery_replacement_years)
    except NameError:
        batt_repl_years = set(battery_replacement_years if isinstance(battery_replacement_years, list)
                              else [battery_replacement_years])

    fc_repl_years = set(fuelcell_replacement_years)

    rows = []
    FC_base = SV(FuelConsTotal_adjusted)*annual_trips
    FC_year = FC_base  # start year
    fc_rep_years = set(fuelcell_replacement_years)
    bat_rep_years = set(battery_replacement_years)

    for t in range(1, years + 1):
        FC_boil_off_t = FC_year * boil_off_rate
        fuel_used_t = (FC_year+FC_boil_off_t)*d
        disc_fuel_cost_t = (fuel_used_t * cost_hydrogen) / ((1 + ir) ** t)

        # Replacements (if any a specific year)
        disc_fc_repl_t  = (Nfc_val * Pfc_rated * Cost_fuelcell_replace) / ((1 + ir) ** t) if t in fc_repl_years else 0.0
        disc_bat_repl_t = (Nbat_val * Ebatt_rated * Cost_batt_replace) / ((1 + ir) ** t) if t in batt_repl_years else 0.0

        # Maintenance (discounted)
        disc_maint_t = (annual_maint) / ((1 + ir) ** t)

        # Year total (discounted)
        disc_total_t = disc_fuel_cost_t + disc_fc_repl_t + disc_bat_repl_t + disc_maint_t

        rows.append({
            "Year": t,
            "Fuel_kg": fuel_used_t,
            "Disc_Fuel_$": disc_fuel_cost_t,
            "Disc_FC_Repl_$": disc_fc_repl_t,
            "Disc_Batt_Repl_$": disc_bat_repl_t,
            "Disc_Maint_$": disc_maint_t,
            "Disc_Total_$": disc_total_t
        })

 # Prepare NEXT year's starting value
        FC_year = fuel_used_t
        if t in fc_repl_years:
            FC_year = FC_base
        









    print("\n================  Annual Breakdown (discounted $)  ================")
    print(f"{'Yr':>2} | {'Fuel [kg]':>14} | {'Fuel $':>12} | {'FC repl $':>12} | {'Batt repl $':>12} | {'Maint $':>12} | {'Total $':>13}")
    print("-"*88)
    for r in rows:
        print(f"{r['Year']:2d} | {r['Fuel_kg']:14,.1f} | {r['Disc_Fuel_$']:12,.0f} | "
              f"{r['Disc_FC_Repl_$']:12,.0f} | {r['Disc_Batt_Repl_$']:12,.0f} | "
              f"{r['Disc_Maint_$']:12,.0f} | {r['Disc_Total_$']:13,.0f}")

    # check
    tot_disc_fuel   = sum(r["Disc_Fuel_$"] for r in rows)
    tot_disc_fc     = sum(r["Disc_FC_Repl_$"] for r in rows)
    tot_disc_batt   = sum(r["Disc_Batt_Repl_$"] for r in rows)
    tot_disc_maint  = sum(r["Disc_Maint_$"] for r in rows)
    tot_disc_all    = sum(r["Disc_Total_$"] for r in rows)

    print("-"*88)
    print(f"Σ Fuel $      : {tot_disc_fuel:,.0f}")
    print(f"Σ FC repl $   : {tot_disc_fc:,.0f}")
    print(f"Σ Batt repl $ : {tot_disc_batt:,.0f}")
    print(f"Σ Maint $     : {tot_disc_maint:,.0f}")
    print(f"Σ All (OPEX)  : {tot_disc_all:,.0f}")

    try:
        print(f"\nCheck vs model:")
        print(f"  NPV OPEX (fuel+repl)  : {SV(NPV_opex_expr):,.0f}")
        print(f"  NPV Maintenance       : {SV(NPV_maintenance_expr):,.0f}")
        print(f"  Sum printed (should ~= OPEX+Maint): {tot_disc_all:,.0f}")
    except Exception:
        pass



# PLOTTING

if best is None:
    print("\n[Plots skipped] No feasible/optimal solution available.")
else:
    def SV(x): return model.getSolVal(best, x)

  #  Output folder 
    save_dir = r"C:\Users\fmylonopoulos\OneDrive - Delft University of Technology\Desktop\THESIS\chapter4_stability_extra"
    os.makedirs(save_dir, exist_ok=True)
    print(f"[saving figures to] {save_dir}")


    
    Pfc_values   = [SV(Pfc[i]) for i in range(ntime)]
    Pbatt_values = [SV(Pbatt[i]) for i in range(ntime)]
    SoC_values   = [SV(SoC[i]) * 100.0 for i in range(ntime)]  # convert to %

    Nfc_val  = SV(Nfc)
    Nbat_val = SV(Nbat)

    try:
        demand_series = demand.values.tolist()
    except AttributeError:
        demand_series = list(demand)

    # (a) Total fuel cell & battery power vs total demand
    plt.figure()
    plt.plot(time, [Nfc_val * p for p in Pfc_values], label="Fuel Cell Total Power")
    plt.plot(time, [Nbat_val * p for p in Pbatt_values], label="Battery Total Power")
    plt.plot(time, demand_series, linestyle="--", label="Power Demand")
    plt.xlabel("Time (hours)")
    plt.ylabel("Power (kW)")
    plt.legend()
    plt.tight_layout(pad=1)
    plt.savefig(os.path.join(save_dir, "power_contributions.png"), dpi=400, bbox_inches='tight', format='png')
    plt.show()

    # (b) Battery SoC over time
    plt.figure()
    plt.plot(time, SoC_values)
    plt.xlabel("Time (hours)")
    plt.ylabel("SoC (%)")
    #plt.legend()
    plt.tight_layout(pad=1)
    plt.savefig(os.path.join(save_dir, "battery_soc.png"), dpi=400, bbox_inches='tight', format='png')
    plt.show()

    # (c) Fuel consumption increase due to degradation & boil-off (annual)
    years_list  = list(range(1, years + 1))
    base_yearly = SV(FuelConsTotal_adjusted) * annual_trips   # baseline (no degr./boil-off)
    FC_year     = base_yearly
    fc_used     = []
    fc_repl_set = set(fuelcell_replacement_years)

    for t in years_list:
        FC_boil_off  = FC_year * boil_off_rate
        FC_year_used = (FC_year + FC_boil_off) * d  # includes degradation factor 'd'
        fc_used.append(FC_year_used)
        FC_year = FC_year_used
        if t in fc_repl_set:
            FC_year = base_yearly

    plt.figure()
    plt.plot(years_list, fc_used, marker='o', linestyle='-')
    plt.xlabel("Year")
    plt.ylabel("H2 Consumption (kg)")
    #plt.legend()
    plt.tight_layout(pad=1)
    plt.savefig(os.path.join(save_dir, "fuel_consumption_over_time.png"), dpi=400, bbox_inches='tight', format='png')
    plt.show()

    # (d) GZ–PHI 
    plt.figure()
    plt.plot(theta_degrees, [GZ_vals[t] for t in theta_degrees], linestyle='-')
    plt.xlabel("Heel angle φ (deg)")
    plt.ylabel("GZ (m)")
    plt.tight_layout(pad=1)
    plt.savefig(os.path.join(save_dir, "gz_phi.png"), dpi=400, bbox_inches='tight', format='png')
    plt.show()



# reporting

if best is None:
    print("\n[Report skipped] No feasible/optimal solution available.")
else:
    
    def SV(x):
        import numbers
        try:
            import numpy as _np
            if isinstance(x, (numbers.Number, _np.number)):
                return float(x)
        except Exception:
            if isinstance(x, numbers.Number):
                return float(x)

        try:
            return float(model.getVal(x))
        except Exception:
            pass
        try:
            return float(model.getSolVal(best, x))
        except Exception:
            pass

        try:
            return float(x)
        except Exception:
            print(f"[warn] Could not evaluate {x!r}")
            return float("nan")

    # --- Margin (2% of original lightship) for reporting ---
    margin_mass  = 0.02 * original_lightship_weight                 # kg
    MARGIN_Z_KG  = 8                                              # m (vertical)
    MARGIN_X_LCG = AFT_ER_AP + 8                            # m (longitudinal)
    margin_vert_mom = margin_mass * MARGIN_Z_KG                     # kg·m
    margin_long_mom = margin_mass * MARGIN_X_LCG                    # kg·m

    # ---------- Per-trip H2 consumption & remaining-in-tank ----------
    per_trip_h2 = SV(FuelConsTotal_adjusted)  # kg/trip
    tank_h2_capacity = per_trip_h2 * no_trips_before_refueling
    print("\n=== Trip-by-trip H2 (single refuel block) ===")
    print(f"Trips before refuel: {no_trips_before_refueling}   |  Tank capacity (with margin) [kg H2]: {tank_h2_capacity:,.1f}")
    remaining = tank_h2_capacity
    for t in range(1, no_trips_before_refueling + 1):
        remaining -= per_trip_h2
        print(f"After trip {t:>2}: consumed {per_trip_h2:,.1f} kg  |  remaining in tank: {max(remaining,0):,.1f} kg")


    Pfc_vals   = [SV(Pfc[i]) for i in range(ntime)]
    Pbatt_vals = [SV(Pbatt[i]) for i in range(ntime)]
    SoC_vals   = [SV(SoC[i]) for i in range(ntime)]
    def stats(a): 
        return (min(a), sum(a)/len(a), max(a))
    pfc_min, pfc_avg, pfc_max = stats(Pfc_vals)
    pbt_min, pbt_avg, pbt_max = stats(Pbatt_vals)
    soc_min, soc_avg, soc_max = stats(SoC_vals)
    print("\n=== Timeseries stats (per-step variables) ===")
    print(f"Pfc per-stack [kW]  -> min:{pfc_min:.2f}  avg:{pfc_avg:.2f}  max:{pfc_max:.2f}")
    print(f"Pbatt per-unit [kW] -> min:{pbt_min:.2f}  avg:{pbt_avg:.2f}  max:{pbt_max:.2f}")
    print(f"SoC (0–1)           -> min:{soc_min:.3f} avg:{soc_avg:.3f} max:{soc_max:.3f}")

    # TANK
    print("\n=== Tank sizing ===")
    print(f"Tank volume [m^3]     : {SV(tank_volume):.3f}")
    print(f"Tank diameter [m]     : {SV(tank_diameter):.3f}")
    print(f"Tank structural mass [kg] (per tank): {SV(tank_weight):,.1f}")
    print(f"No. tanks             : {no_tanks}")
    print(f"Hydrogen in tank [kg] : {tank_h2_capacity:,.1f}")

    # WEIGHTS
    print("\n=== Weights (lightship & DWT) ===")
    print(f"Lightship_nom (incl. new equip, excl. margin) [kg] : {SV(lightship_weight_nom):,.1f}")
    print(f"Margin mass (2% of original lightship) [kg]        : {margin_mass:,.1f}")
    print(f"DWT (incl. fuel on weight side) [kg]               : {SV(DWT_weight_expr):,.1f}")
    print(f"W_nom = Lightship_nom + DWT [kg]                   : {SV(W_nom):,.1f}")
    print(f"W_tot (model) [kg]                                 : {SV(W_tot):,.1f}")
    print(f"Displacement [kg]                                  : {SV(displacement):,.1f}")
    print(f"Weight cap 1.05×Original [kg]                      : {1.05*Original_total_weight:,.0f}")
    print(f"Weight cap check                                   : {'OK' if SV(W_tot) <= 1.05*Original_total_weight + 1e-6 else 'VIOLATION'}")

    # VCG components
    print("\n=== Vertical CG (moments & KG) ===")
    print(f"FC KG moment [kg·m]                  : {SV(fc_KG_expr):,.1f}")
    print(f"Converters KG moment [kg·m]          : {SV(conv_KG_expr):,.1f}")
    print(f"Fixed equip KG moment [kg·m]         : {SV(fixed_equip_KG_expr):,.1f}")
    print(f"Total added KG moment [kg·m]         : {SV(total_added_KG_moment):,.1f}")
    print(f"Adjusted DWT weight [kg]             : {SV(adjusted_DWT_weight):,.1f}")
    print(f"Adjusted DWT KG contribution [m]     : {SV(adj_DWT_KG_var):,.4f}")
    print(f"Fuel weight (block) [kg]             : {SV(fuel_weight):,.1f}")
    print(f"KG of hydrogen fuel [m]              : {SV(KG_hydrogen_fuel):.3f}")
    print(f"Margin mass vertical moment [kg·m]   : {margin_vert_mom:,.1f}")
    print(f"FSM_tank [ton·m]                     : {SV(FSM_tank):,.1f}")
    print(f"FSM_total_corrected [kg·m]           : {SV(FSM_total_corrected):,.1f}")

    # FSM AND GG
    W_tot_val     = SV(W_tot)
    FSM_corr_val  = SV(FSM_total_corrected)
    GG_corr_val   = FSM_corr_val / W_tot_val if abs(W_tot_val) > 1e-12 else float('nan')
    print(f"GG correction [m]                    : {GG_corr_val:.4f}")
    print(f"New KG [m] (limit {KG_MAX_LIMIT})    : {SV(new_KG):.4f}")

    # LCG
    print("\n=== Longitudinal moments & LCG ===")
    print(f"FC L-moment [kg·m]                   : {SV(fc_L_moment):,.1f}")
    print(f"Converters L-moment [kg·m]           : {SV(conv_L_moment):,.1f}")
    print(f"Batteries L-moment [kg·m]            : {SV(bat_L_moment):,.1f}")
    print(f"Tank L-moment [kg·m]                 : {SV(tank_L_moment):,.1f}")
    print(f"Motor L-moment [kg·m]                : {SV(Motor_L_moment):,.1f}")
    print(f"Gearbox L-moment [kg·m]              : {SV(Gearbox_L_moment):,.1f}")
    print(f"Inverter L-moment [kg·m]             : {SV(Inverter_L_moment):,.1f}")
    print(f"Margin mass longitudinal moment [kg·m]: {margin_long_mom:,.1f}")
    print(f"Lightship L-moment [kg·m]            : {SV(lightship_moment_expr):,.1f}")
    print(f"DWT L-moment [kg·m]                  : {SV(DWT_moment_expr):,.1f}")
    print(f"Total moment [kg·m]                  : {SV(total_moment_expr):,.1f}")
    print(f"Total weight [kg]                    : {SV(total_weight_expr):,.1f}")
    print(f"New total LCG [m]                    : {SV(new_total_LCG):,.3f}")

    # Hydrostatics 
    print("\n=== Hydrostatics (interpolated) ===")
    print(f"MCT [t·m/cm] (interp)               : {SV(MCT_i):.3f}")
    print(f"LCB [m] (interp)                    : {SV(LCB_i):,.3f}")
    print(f"KM_transverse [m] (interp)          : {SV(KM_i):,.3f}")
    print(f"Trim [m] (constraint bounds)        : {SV(new_trim):.4f}  in [{-0.48}, {-0.38}]")
    print(f"GM = KM - KG [m]                    : {SV(KM_i)-SV(new_KG):.4f}  (≥ {GM_min})")

    # capex components
    print("\n=== CAPEX components (raw $) ===")
    Nfc_val, Nbat_val = SV(Nfc), SV(Nbat)
    cap_fc    = Nfc_val * Pfc_rated    * Cost_fc
    cap_bat   = Nbat_val * Ebatt_rated * Cost_bat
    cap_conv  = (Nfc_val * Pfc_rated + Nbat_val * Ebatt_rated) * Cost_converters
    cap_tank  = Cost_LH2_tank * margin_tanksize * SV(FuelConsTotal_adjusted) * no_trips_before_refueling * tank_no_cost_factor
    cap_motor = n_motor * motor_power * Cost_motors
    cap_inv   = n_inverter * inverter_power * Cost_converters
    cap_gbx   = n_gearbox * Cost_gearbox
    print(f"Fuel cells            : {cap_fc:,.0f}")
    print(f"Batteries             : {cap_bat:,.0f}")
    print(f"Converters (FC+BAT)   : {cap_conv:,.0f}")
    print(f"Tanks (H2 mass based) : {cap_tank:,.0f}")
    print(f"Motors                : {cap_motor:,.0f}")
    print(f"Inverters (VFDs)      : {cap_inv:,.0f}")
    print(f"Gearbox(es)           : {cap_gbx:,.0f}")
    print(f"Σ CAPEX               : {SV(CAPEX_expr):,.0f}")
